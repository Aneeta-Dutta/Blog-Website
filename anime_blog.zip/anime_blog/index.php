<?php 
session_start();
require "admin/db.php";
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Anime Blog</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.3-web/css/all.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200&display=swap" rel="stylesheet">
	 <style>
  /* Make the image fully responsive */

  *{

  	padding: 0;
  	margin: 0;
  	font-family: 'Poppins', sans-serif;
  }
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }
  .card-img-top {
  	height: 250px;
  }
  .dark-mode {
  background-color: black;
  color: white;
	}
	.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}


}
 
  </style>



</head>
<body>

<header>
	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
		  <a class="navbar-brand" href="#">
		  	<h3>Anime Blog</h3>
		  </a>

		  <!-- Toggler/collapsibe Button -->
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span class="navbar-toggler-icon"></span>
		  </button>

	  <!-- Navbar links -->
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		    <ul class="navbar-nav ml-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="#">Home</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="#about">About</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="#portfolio">Portfoio</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="blog.php">Blog</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="gallery.php">Gallery</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="animelist.php">Content</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contactus.php">Contact</a><br>
		      </li>
		      <li class="nav-item">
		      	<input type="text" placeholder="Search..">
		      </li>
		    </ul>
		  </div>
	</nav>
				<?php 

				$sql ="SELECT * FROM `image_slider`";

					$result = mysqli_query($connection, $sql);
					$count = mysqli_num_rows($result);
					
				 ?>
			<div id="demo" class="carousel slide" data-ride="carousel">

			  <!-- Indicators -->
			  <ul class="carousel-indicators">
			  
			  	<?php 

			  	// $data_slide = 0;
			  	for($data_slide = 0; $data_slide < $count; $data_slide++){
			  		$active ='';
			  		if ($data_slide == 0){
			  			$active ='active';
			  		}
			  		?>

			  		<li data-target="#demo" data-slide-to="<?php echo $data_slide; ?>" class="<?php echo $active; ?>"></li>

			  <?php	
			
			}
			 ?>

			  </ul>
			  
			  <!-- The slideshow -->
			  <div class="carousel-inner">
			    <?php 

			  	$data_slide = 0;
			  		while ($row = mysqli_fetch_assoc($result)){
			  		$active ='';
			  		if ($data_slide == 0){
			  			$active ='active';
			  		}
			  		?>
			    <div class="carousel-item <?php echo $active; ?>">
			      <img src="admin/images_slider/<?php echo $row['image']; ?>"  width="1100" height="500">
			    </div>
			  	  <?php	
			  	  $data_slide ++;
			}
			 ?>

			  </div>
			  
			  <!-- Left and right controls -->
			  <a class="carousel-control-prev" href="#demo" data-slide="prev">
			    <span class="carousel-control-prev-icon"></span>
			  </a>
			  <a class="carousel-control-next" href="#demo" data-slide="next">
			    <span class="carousel-control-next-icon"></span>
			  </a>
			</div>
	</header>

	<section class="mt-4" id="about">
		<div class="container-fluid bg-secondary">
			<h1 class="text-white text-center bg-warning text-white">About Us</h1>
			<hr class="w-25 mx-auto">
			<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12 col-12"><br>

						<h2 class="text-white text-center bg-light text-dark">About Me</h2>
					
						<hr class="w-25 mx-auto">
						<p class="bg-dark text-white">
							<h3>
							Hello I'm Annie the owner of this page.<br> I have made this blog for anime fans.
							The sole purpose of this page is to entertain people.<br> 
							I hope you enjoy this page.</h3>
						</p><br>

					<div class="container text-center bg-dark text-white">
						<form>
					<div class="row">    
						<div class="col-25" align="card-img-top"> 
						<h4 class="bg-dark text-white">Feedback : </h4>   
						</div>
						<div class=" col-75 bg-dark text-white">  
						     <textarea id="subject" name="subject" placeholder="Write something.." style="height:400px width: 400px"></textarea><br>
						     <button type="button" class="btn btn-success" value="submit">Submit</button>
						</div>    
					</div>      
						</form>    
					</div>    
					</div>

					<div class="col-lg-6 col-md-6 col-sm-12 col-12 pb-4">
						
						<section class="container-fluid text-center mt-4">
						<div class="row">
						  <div class="column">
						    <div class="card">
						      <img src="images/22.jpg" alt="Annie" style="width:100%">
						      <div class="container">
						        <h2>Annie D</h2>
						        <p class="title">Owner Of This Page</p>
						        <p>This is a demo page.</p>
						        <p>example@example.com</p>
						        <p><button class="button">Contact</button></p>
						      </div>
						    </div>
						  </div>
						</section>
						<!-- <img src="images/animegirl.jpg" class="img-fluid"> -->
					</div>
			</div>
		
		</div>
	</section>

		<section>
		<div class="container-fluid text-center bg-warning text-white">
			<h1 class="text-white pt-4">Join Now</h1>
			<button type="button" class="btn btn-success my-4" data-toggle="modal" data-target="#myModalLogin">Login</button>
			<button type="button" class="btn btn-success my-4" data-toggle="modal" data-target="#myModal">Register</button>
		</div>
	</section>

	<section class="mt-4" id="portfolio">
		<div class="container bg-dark text-black">
			<h1 class="text-center text-white">Portfolio</h1>
			<hr class="w-25 mx-auto pb-4">
			<div class="row text-center">
				
				<?php 
				  	$sql ="SELECT * FROM `portfolio` LIMIT 6";

					$result = mysqli_query($connection, $sql);

				  	 while ($get = mysqli_fetch_assoc($result)) {?>
				<div class="col-lg-4 col-md-4 col-sm-12 col-12 pb-4">
					<div class="card">
						  <img class="card-img-top" src="admin/portfolio_image/<?php echo $get['image'] ?>" alt="Card image">
						  <div class="card-body">
						    <h4 class="card-title"><?php echo $get['name'] ?></h4>
						    <p class="card-text"><?php echo $get['details'] ?></p>
						    <a href="admin/portfolio_image/<?php echo $get['image'] ?>" class="btn btn-primary">See Profile</a>
						  </div>
					</div>
				</div>

				<?php 

			}
				 ?>

			</div>
		</div>
	</section>	


	<section>
		<div class="container-fluid text-center bg-secondary text-white">
			<h1 class="text-white pt-4">Contact Us Now</h1>
			<button type="button" class="btn btn-success my-4" data-toggle="modal" data-target="#myModal">Contact</button>
		</div>
	</section>


<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h3 class="modal-title">Registration</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="user/user-add-action.php" method="post" enctype="multipart/form-data">
        	<div class="form-group">
        		<label>First Name</label>
        		<input type="text" name="fname" class="form-control">
        	</div>
        	<div class="form-group">
        		<label>Last Last Name</label></label>
        		<input type="text" name="lname" class="form-control">
        	</div>


        	<div class="form-group">
        		<label>Email</label>
        		<input type="email" name="email" class="form-control">
        	</div>

        	<div class="form-group">
        		<label>Password</label>
        		<input type="password" name="password" class="form-control">
        	</div>

        	<div class="form-group">
        		<label>Mobile No.</label>
        		<input type="number" name="phone" class="form-control">
        	</div>
        	
        	<div class="form-group">
        		<label>Image</label>
        		<input type="file" name="image" class="form-control">
        	</div>

        	<button type="submit" name="submit_reg" class="btn btn-success">Register</button>
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<div class="modal" id="myModalLogin">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h3 class="modal-title">Login</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="user/login-action.php" method="post">
        	

        	<div class="form-group">
        		<label>Email</label>
        		<input type="email" name="email" class="form-control">
        	</div>

        	<div class="form-group">
        		<label>Password</label>
        		<input type="password" name="password" class="form-control">
        	</div>

        	

        	<button type="submit" name="submit_login" class="btn btn-success">Login</button>
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<?php
if (isset($_SESSION['register'])) {?>
	
	<script>alert('<?php echo $_SESSION['register'] ?>');</script>
<?php
unset($_SESSION['register']);
}

elseif (isset($_SESSION['email_exist'])) {?>
	<script>alert("<?php echo $_SESSION['email_exist'] ?>");</script>
<?php
unset($_SESSION['email_exist']);
}


 ?>
 			<div class="container-fluid text-center bg-secondary text-white">
 			<button class="btn btn-warning" onclick="myFunction()" ><i class="lni lni-spinner"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16"><path fill-rule="evenodd" d="M8 10.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM8 12a4 4 0 100-8 4 4 0 000 8zM8 0a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0V.75A.75.75 0 018 0zm0 13a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 018 13zM2.343 2.343a.75.75 0 011.061 0l1.06 1.061a.75.75 0 01-1.06 1.06l-1.06-1.06a.75.75 0 010-1.06zm9.193 9.193a.75.75 0 011.06 0l1.061 1.06a.75.75 0 01-1.06 1.061l-1.061-1.06a.75.75 0 010-1.061zM16 8a.75.75 0 01-.75.75h-1.5a.75.75 0 010-1.5h1.5A.75.75 0 0116 8zM3 8a.75.75 0 01-.75.75H.75a.75.75 0 010-1.5h1.5A.75.75 0 013 8zm10.657-5.657a.75.75 0 010 1.061l-1.061 1.06a.75.75 0 11-1.06-1.06l1.06-1.06a.75.75 0 011.06 0zm-9.193 9.193a.75.75 0 010 1.06l-1.06 1.061a.75.75 0 11-1.061-1.06l1.06-1.061a.75.75 0 011.061 0z"></path></svg></i>Change To Dark Mode </button>

			<script>
			function myFunction() {
			   var element = document.body;
			   element.classList.toggle("dark-mode");
			}
			</script>
			</div><br>

			<div class="container-fluid text-center">
				<a href="https://www.pinterest.com" fa-2x><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-7 20c-.825 0-1.62-.125-2.369-.357.326-.531.813-1.402.994-2.098l.499-1.901c.261.498 1.023.918 1.833.918 2.414 0 4.152-2.219 4.152-4.976 0-2.643-2.157-4.62-4.933-4.62-3.452 0-5.286 2.317-5.286 4.841 0 1.174.625 2.634 1.624 3.1.151.07.232.039.268-.107l.222-.907c.019-.081.01-.15-.056-.23-.331-.4-.595-1.138-.595-1.825 0-1.765 1.336-3.472 3.612-3.472 1.965 0 3.341 1.339 3.341 3.255 0 2.164-1.093 3.663-2.515 3.663-.786 0-1.374-.649-1.185-1.446.226-.951.663-1.977.663-2.664 0-.614-.33-1.127-1.012-1.127-.803 0-1.448.831-1.448 1.943 0 .709.239 1.188.239 1.188s-.793 3.353-.938 3.977c-.161.691-.098 1.662-.028 2.294-2.974-1.165-5.082-4.06-5.082-7.449 0-4.418 3.582-8 8-8s8 3.582 8 8-3.582 8-8 8z"/></svg></a>
				<a href="https://www.facebook.com"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z"/></svg></a>
				<a href="https://www.instagram.com"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg></a>
				<a href="https://www.tumblr.com"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-1.105 18.739c-.524.691-2.29 1.261-3.889 1.261-3.979 0-6.006-1.466-6.006-4.573v-4.104h-1.933l-.067-.067v-3.16l.045-.064.178-.059c1.597-.534 2.624-1.432 2.851-3.284.055-.447.431-.689.757-.689h4.767l.066.067v3.211l.066.067h2.535l.068.067v3.844l-.068.067h-2.545l-.067.067v3.81c.002.103.006.414.109.414h2.182l.064.046.992 2.941-.105.138zm-1.309-2.278l.664 1.967-.016.07c-.5.48-1.703.837-2.686.854l-.111.001c-3.232 0-3.788-2.468-3.788-3.926v-4.692l-.066-.067h-1.854l-.067-.067-.016-2.041.042-.062c1.67-.65 2.604-1.73 2.849-3.729.014-.111.105-.114.106-.114h2.298l.067.067v3.211l.068.067h2.535l.066.067v2.534l-.066.067h-2.547l-.064.067v4.47c.016.959.477 1.445 1.377 1.445.362 0 .744-.084 1.123-.229l.086.04z"/></svg></a>

			</div>
			
	<footer class="mt-4">
		<div class="container-fluid text-center">
			<h4 class="bg-dark text-white">&copy; Aneeta Dutta 2021</h4>
		</div>
	</footer>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>