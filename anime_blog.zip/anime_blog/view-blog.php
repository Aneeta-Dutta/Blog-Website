<?php 
session_start();
require "admin/db.php";

$id = $_GET["blog_id"];

$sql = "SELECT * FROM `blog` WHERE `id`= '$id'";

$result = mysqli_query($connection, $sql);

$row = mysqli_fetch_array($result);
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Anime Blog</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.3-web/css/all.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200&display=swap" rel="stylesheet">
	 <style>
  /* Make the image fully responsive */

  *{

  	padding: 0;
  	margin: 0;
  	font-family: 'Poppins', sans-serif;
  }
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }
  .card-img-top {
  	height: 250px;
  }
 
  </style>



</head>
<body>

<header>
	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
		  <a class="navbar-brand" href="#">
		  	<h3>Anime Blog</h3>
		  </a>

		  <!-- Toggler/collapsibe Button -->
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span class="navbar-toggler-icon"></span>
		  </button>

	  <!-- Navbar links -->
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		    <ul class="navbar-nav ml-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">Home</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">About</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="#portfolio">Portfoio</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="blog.php">Blog</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="gallery.php">Gallery</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="animelist.php">Content</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contactus.php">Contact</a>
		      </li>
		    </ul>
		  </div>
	</nav>
</header>

<section class="mt-4">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-9 col-sm-6">
				<h1 class="text-center"><?php echo $row['name'] ?></h1>
				<img class="img-fluid" src="user/blog_images/<?php echo $row['image'] ?>">
				<p class="mt-3">By <?php echo $row['author']; ?></p>
				<p>Created At <?php echo $row['created_at']; ?></p>
				<div class="mt-5">
					<?php echo $row['content'] ?>
				</div>
				
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 text-center">
				<h3 class="mt-5 "> All Blogs</h3>
				<ul class="list-group list-group-flush mt-3 ">

					<?php 
					$sql = "SELECT * FROM `blog`";
					$result = mysqli_query($connection, $sql);
					while ($row = mysqli_fetch_array($result)){
					 ?>
					<li class="list-group-item"><a href="view-blog.php?blog_id=<?= $row['id'] ?>"><?php echo $row['name'] ?></a></li>


					<?php
				}
				?>
				  
				 
				</ul>
			</div>
		</div>
	</div>
</section>

<footer class="mt-4">
	<div class="container-fluid text-center">
		<h4 class="bg-dark text-white">&copy; Aneeta Dutta 2021</h4>
	</div>
</footer>