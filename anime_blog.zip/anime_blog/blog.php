<?php 
session_start();
require "admin/db.php";
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Anime Blog</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.3-web/css/all.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200&display=swap" rel="stylesheet">
	 <style>
  /* Make the image fully responsive */

  *{

  	padding: 0;
  	margin: 0;
  	font-family: 'Poppins', sans-serif;
  }
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }
  .card-img-top {
  	height: 250px;
  }
 
  </style>



</head>
<body>

<header>
	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
		  <a class="navbar-brand" href="#">
		  	<h3>Anime Blog</h3>
		  </a>

		  <!-- Toggler/collapsibe Button -->
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span class="navbar-toggler-icon"></span>
		  </button>

	  <!-- Navbar links -->
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		    <ul class="navbar-nav ml-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">Home</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">About</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="#portfolio">Portfoio</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="blog.php">Blog</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="gallery.php">Gallery</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contactus.php">Contact</a>
		      </li>
		    </ul>
		  </div>
	</nav>
</header>

	<section class="mt-4" id="portfolio">
		<div class="container">
			<h1 class="text-center">Portfolio</h1>
			<hr class="w-25 mx-auto pb-4">
			<div class="row text-center">
				
				<?php 
				  	$sql ="SELECT * FROM `blog`";

					$result = mysqli_query($connection, $sql);

				  	 while ($get = mysqli_fetch_assoc($result)) {?>
				<div class="col-lg-4 col-md-4 col-sm-12 col-12 pb-4">
					<div class="card">
						  <img class="card-img-top" src="user/blog_images/<?php echo $get['image'] ?>" alt="Card image">
						  <div class="card-body">
						  	<a href="view-blog.php?blog_id=<?php echo $get['id'] ?>">
						  		<h4 class="card-title"><?php echo $get['name'] ?></h4>
						  	</a>
						    
						    <a href="view-blog.php?blog_id=<?php echo $get['id'] ?>" class="btn btn-primary">Read more</a>
						  </div>
					</div>
				</div>

				<?php 

			}
				 ?>

			</div>
		</div>
	</section>

		<footer class="mt-4">
		<div class="container-fluid text-center">
			<h4 class="bg-dark text-white">&copy; Aneeta Dutta 2021</h4>
		</div>
	</footer>