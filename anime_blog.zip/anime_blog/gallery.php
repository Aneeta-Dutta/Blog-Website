<?php 
session_start();
require "admin/db.php";
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Anime Blog</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.3-web/css/all.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200&display=swap" rel="stylesheet">
	
	<style>
		*{
			padding: 0;
			margin: 0;
		}
		.container {
		  position: relative;
		  text-align: center;
		  color: white;
		}
		
		.bg{
			background-image: url(images/18.jpg);

			height: 50px;

			background-position: center;
			background-repeat: no-repeat;
			background-size: cover;
		}

	</style>

 </head>
 <body>
 	<header>
 			<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
		  <a class="navbar-brand" href="#">
		  	<h3>Anime Blog</h3>
		  </a>

		  <!-- Toggler/collapsibe Button -->
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span class="navbar-toggler-icon"></span>
		  </button>

	  <!-- Navbar links -->
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		    <ul class="navbar-nav ml-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">Home</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">About</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="index.php#portfoio">Portfoio</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="blog.php">Blog</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="gallery.php">Gallery</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="animelist.php">Content</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contactus.php">Contact</a>
		      </li>
		    </ul>
		  </div>
	</nav>

 	</header>


<section>
 	<div class="bg">
    	<h1 class="text-center">Images</h1></div>
</section>

 		<section class="mt-4" id="image">
		<div class="container">
			
			<hr class="w-25 mx-auto pb-4">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<!-- <img src="images/md.jpg" class="img-thumbnail img-fluid"> -->
					<a href="images/md.jpg"><img src="images/md.jpg" class="img-thumbnail img-fluid"></a>
					</a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/animegirl1.jpg"><img src="images/animegirl1.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/02.jpg"><img src="images/02.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/03.jpg"><img src="images/03.jpg" class="img-thumbnail img-fluid"></a>
				</div>

					<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/06.jpg"><img src="images/06.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/07.jpg"><img src="images/07.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/08.jpg"><img src="images/08.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/09.jpg"><img src="images/09.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/16.jpg"><img src="images/16.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/17.jpg"><img src="images/17.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/19.jpg"><img src="images/19.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/10.jpg"><img src="images/10.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/14.jpg"><img src="images/14.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/11.jpg"><img src="images/11.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/12.jpg"><img src="images/12.jpg" class="img-thumbnail img-fluid"></a>
				</div>

				<div class="col-lg-3 col-md-3 col-sm-12 col-12 pb-4">
					<a href="images/22.jpg"><img src="images/22.jpg" class="img-thumbnail img-fluid"></a>
				</div>

			</div>
		</div>
	</section>
 
 </body>
 </html>