<?php 
session_start();
require "admin/db.php";
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Anime Blog</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.3-web/css/all.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200&display=swap" rel="stylesheet">

	<style>
body, html {
  height: 100%;
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

.bg-image {
  /* The image used */
  background-image: url("images/18.jpg");
  
  /* Add the blur effect */
  filter: blur(8px);
  -webkit-filter: blur(8px);
  
  /* Full height */
  height: 100%; 
  
  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

/* Position text in the middle of the page/image */
.bg-text {
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0, 0.4); /* Black w/opacity/see-through */
  color: white;
  font-weight: bold;
  border: 1px solid #f1f1f1;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 2;
  width: 80%;
  padding: 20px;

}
</style>


	<title></title>
</head>
<body>
	<header>
			<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
		  <a class="navbar-brand" href="#">
		  	<h3>Anime Blog</h3>
		  </a>

		  <!-- Toggler/collapsibe Button -->
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span class="navbar-toggler-icon"></span>
		  </button>

	  <!-- Navbar links -->
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		    <ul class="navbar-nav ml-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">Home</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">About</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="index.php">Portfoio</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="blog.php">Blog</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="gallery.php">Gallery</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="animelist.php">Content</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contactus.php">Contact</a>
		      </li>
		    </ul>
		  </div>
	</nav>
	</header>

			<div class="bg-image"></div>

<div class="bg-text">
  <section class="mt-4" id="contact">
		<div class="container">
			<h1 class="text-center">Contact Us</h1>
			<hr class="w-25 mx-auto pb-4">

			<div class="w-50 mx-auto">
				<form>
	        	<div class="form-group">
	        		<label>Name</label>
	        		<input type="text" class="form-control">
	        	</div>

	        	<div class="form-group">
	        		<label>Email</label>
	        		<input type="email" class="form-control">
	        	</div>

	        	<div class="form-group">
	        		<label>Subject</label>
	        		<input type="text" class="form-control">
	        	</div>

	        	<div class="form-group">
	        		<label>Content</label>
	        		<textarea class="form-control"></textarea>
	        	</div>

	        	<button type="button" class="btn btn-success">Submit</button>
	        </form>
			</div>
			
		</div>
	</section>
</div>

</body>
</html>
	