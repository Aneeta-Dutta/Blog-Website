<?php 

$connection = mysqli_connect('localhost', 'root', '', 'anime_blog');

if (!$connection){

	die("Conection Error");

}

 ?>