<?php 
session_start();
require "db.php";

$id = $_GET['id'];

$query =  "SELECT * FROM `portfolio` WHERE `id` = '$id'";

$res = mysqli_query($connection, $query);

$row =  mysqli_fetch_array($res);

$image ='portfolio_image'.'/'.$row['image'];

unlink($image);


$sql = "DELETE FROM `portfolio` WHERE `id` = '$id'";

$result = mysqli_query($connection, $sql);


if ($result) {

	$_SESSION['port_delete'] = "Portfolio deleted successfully";
	header("Location:portfolio.php");
}
else {
	$_SESSION['port_delete'] = "Error";
	header("Location:portfolio.php");
}

 ?>