<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Demo Blog - Admin</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.3-web/css/all.css">
	
</head>
<body>
	<section class="mt-4" id="contact">
		<div class="container">
			<h1 class="text-center">Admin Register</h1>
			<hr class="w-25 mx-auto pb-4">
			<?php

			if (isset($_SESSION['email_exist'])){

				echo "<p>".$_SESSION['email_exist']."</p>";
				unset($_SESSION['email_exist']);
			}

			 ?>
			<div class="w-50 mx-auto">
				<form action="register-action.php" method="post">
	        	
				<div class="form-group">
	        		<label>Name</label>
	        		<input type="text" name="name" class="form-control" required="">
	        	</div>
	        	
	        	<div class="form-group">
	        		<label>Email</label>
	        		<input type="email" name="email" class="form-control" required="">
	        	</div>

	        	<div class="form-group">
	        		<label>Password</label>
	        		<input type="password" name="password" class="form-control" required="">
	        	</div>

	        
	        	<button type="submit" name="submit" class="btn btn-success">Submit</button>
	        	<a href="index.php">Login</a>
	        </form>
			</div>
			
		</div>
	</section>
</body>
</html>