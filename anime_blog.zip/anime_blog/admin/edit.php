<?php 
include "header.php";

include 'sidebar.php';

$id = $_GET['id'];

$sql = "SELECT * FROM `portfolio` WHERE `id` ='$id'";

$result = mysqli_query($connection, $sql);

$row = mysqli_fetch_assoc($result);



?>

<div class="col-md-9">
	<div class="container">
		<h2 class="mt-5">Edit Portfolio Details</h2>
			<div class="w-50 mt-3">
				<form action="edit-action-portfolio.php" method="post" enctype="multipart/form-data">
	        	
				<div class="form-group">
	        		<label>Portfolio Name</label>
	        		<input type="text" name="name" class="form-control" required="" value="<?php echo $row['name']; ?>">
	        	</div>
	        	
	        	<div class="form-group">
	        		<label>Details</label>
	        		<textarea name="details" class="form-control">
	        			<?php echo $row['details']; ?>
	        		</textarea>
	        	</div>

	        	<img class="img-fluid" src="portfolio_image/<?php echo $row['image'] ?>">

	        	<div class="form-group">
	        		<label>Upload Image</label>
	        		<input type="file" name="image" class="form-control">
	        	</div>

	        	<input type="hidden" name="id" value="<?php echo $row['id'] ?>">
	        
	        	<button type="submit" name="submit" class="btn btn-success" value="submit">Edit</button>
	        	
	        </form>
			</div>
	</div>
</div>

<?php 
include "footer.php";

?>