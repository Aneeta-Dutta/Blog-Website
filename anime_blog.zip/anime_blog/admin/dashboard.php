<?php 
include "header.php";

include 'sidebar.php';

 ?>
			<div class="col-md-9">
				<div class="container">
					<h3 class="mt-5">Latest Users Details</h3>
				<table class="table">
				  <thead>
				    <tr>
				      <th>Id</th>
				      <th>Name</th>
				      <th>Email</th>
				      <th>Status</th>
				      <th>Edit</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php 
				  	$sql ="SELECT * FROM `user`";

					$result = mysqli_query($connection, $sql);

				  	 while ($get = mysqli_fetch_assoc($result)) {?>
				    <tr>
				      <td><?php echo $get['id']; ?></td>
				      <td><?php echo $get['name']; ?></td>
				      <td><?php echo $get['email']; ?></td>
				      
				      <?php 
				      if ($get['status'] == 'DEACTIVATE'){?>

				      <td><a class="btn btn-danger" href="#">DEACTIVATED</a></td>
				<?php
				      }
				      else{
				      	?>
				      	<td><a class="btn btn-success" href="#">ACTIVATED</a></td>
				      
				      <?php
				  		}
						?>
				      <td><a class="btn btn-primary" href="change-state.php?id=<?php echo $get['id']; ?>&state=<?php echo $get['status'] ?>">Edit</a></td>
				     
				    </tr>
	<?php
}
?>
				  </tbody>
				</table>
				</div>

				
			</div>	
	

	<?php include "footer.php"; ?>
