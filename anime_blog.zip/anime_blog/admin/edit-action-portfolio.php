<?php 
session_start();
require "db.php";

extract($_POST);

// print_r($_POST);

if (isset($submit)){
	$image = $_FILES['image']['name'];

	if ($image){
		$extension = pathinfo($image, PATHINFO_EXTENSION);

			$num = rand(0, 1000000000);

			$rename = "portfolio_img_".date('ymd').$num;

			$filename = $rename.'.'.$extension;

			$upload = 'portfolio_image';

			$actual_path = $upload.'/'.$filename;

			//unlink($actual_path);
			
			move_uploaded_file($_FILES['image']['tmp_name'], $actual_path);

			$sql = "UPDATE `portfolio` SET `name`='$name',`details`='$details',`image`='$filename' WHERE `id`='$id'";
	}
	else{
		$sql = "UPDATE `portfolio` SET `name`='$name',`details`='$details' WHERE `id`='$id'";
	}
			

		$result =  mysqli_query($connection, $sql);

		echo $result;

		if ($result){
			$_SESSION['edit_portfolio'] = "Edit Portfolio Successfully";
			header('location:portfolio.php');
		}
		else{
			$_SESSION['edit_portfolio'] = "Error";
			header('location:portfolio.php');
		}

		


}




 ?>
