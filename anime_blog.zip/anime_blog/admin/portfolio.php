<?php 
include "header.php";

include 'sidebar.php';
?>
<div class="col-md-9">
	<div class="container">
		<?php 
		if(isset($_SESSION['add_portfolio'])){
			echo"<p>".$_SESSION['add_portfolio']."</p>";
			unset($_SESSION['add_portfolio']);
		 
		}
		elseif (isset($_SESSION['edit_portfolio'])) {
			echo"<p>".$_SESSION['edit_portfolio']."</p>";
			unset($_SESSION['edit_portfolio']);
		}
		elseif (isset($_SESSION['port_delete'])) {
			echo"<p>".$_SESSION['port_delete']."</p>";
			unset($_SESSION['port_delete']);
		}

		elseif (isset($_SESSION['max_file'])) {
			echo"<p>".$_SESSION['max_file']."</p>";
			unset($_SESSION['max_file']);
		}
		elseif (isset($_SESSION['mail'])) {?>
		<script> alert('<?php echo $_SESSION['mail'] ?>');</script>
			
		
		<?php	
		unset($_SESSION['mail']);
		}

		?>
		<h3 class="mt-5">All Portfolio Details</h3>
		<a class="btn btn-primary" href="add-portfolio.php">Add Portfolio</a>
			<table class="table mt-2">
				  <thead>
				    <tr>
				      <th>Id</th>
				      <th>Name</th>
				      <th>Details</th>
				      <th>Images</th>
				      <th>Edit</th>
				      <th>Delete</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php 
				  	$sql ="SELECT * FROM `portfolio`";

					$result = mysqli_query($connection, $sql);

				  	 while ($get = mysqli_fetch_assoc($result)) {?>
				    <tr>
				      <td><?php echo $get['id']; ?></td>
				      <td><?php echo $get['name']; ?></td>
				      <td><?php echo $get['details']; ?></td>
				      <td><img src="portfolio_image/<?php echo $get['image']; ?>" width="100px" height="100px"></td>
				      <td><a class="btn btn-primary" href="edit.php?id=<?php echo $get['id']?>">Edit</a></td>
				      <td><a class="btn btn-danger" href="delete-portfolio.php?id=<?php echo $get['id']?>">Delete</a></td>
				     
				    </tr>
	<?php
}
?>
				  </tbody>
				</table>
	</div>
</div>


<?php 
include "footer.php";

?>