<?php 
session_start();
if(isset($_SESSION['id'])){
	header('Location:dashboard.php');
}
?>


<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Demo Blog - Admin</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.3-web/css/all.css">
	
</head>
<body>
	<section class="mt-4" id="contact">
		<div class="container">
			<h1 class="text-center">Admin Login</h1>
			<hr class="w-25 mx-auto pb-4">
			<?php

			if (isset($_SESSION['register'])){

				echo "<p>".$_SESSION['register']."</p>";

				unset($_SESSION['register']);
			}

			elseif (isset($_SESSION['login_err'])) {
				echo "<p>".$_SESSION['login_err']."</p>";
				unset($_SESSION['login_err']);
			}

			elseif (isset($_SESSION['login_first'])) {
				echo "<p>".$_SESSION['login_first']."</p>";
				unset($_SESSION['login_first']);
			}

			 ?>
			<div class="w-50 mx-auto">
				<form action="login-action.php" method="post">
	        	

	        	<div class="form-group">
	        		<label>Email</label>
	        		<input type="email" name="email" class="form-control" required="">
	        	</div>

	        	<div class="form-group">
	        		<label>Password</label>
	        		<input type="password" name="password" class="form-control" required="">
	        	</div>

	        
	        	<button type="submit" name="submit" class="btn btn-success">Submit</button>
	        	<a href="register.php">Create Account</a>
	        </form>
			</div>
			
		</div>
	</section>
</body>
</html>