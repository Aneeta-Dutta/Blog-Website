<?php 
session_start();
require "db.php";

print_r($_POST);
extract($_POST);

$hash_password = md5($password);
if (isset($submit)){
	$sql = "SELECT * FROM `admin` WHERE email = '$email'";

	$res = mysqli_query($connection, $sql);

	$row = mysqli_num_rows($res);

	if ($row > 0) {
		$_SESSION['email_exist'] = "Email already exists";
		header('location:register.php');
	}
	else{
		$sql = "INSERT INTO `admin`(`name`, `email`, `password`) VALUES ('$name', '$email','$hash_password')";

		$result =  mysqli_query($connection, $sql);

		if ($result){
			$_SESSION['register'] = "Register Successfully Please Login";
			header('location:index.php');
		}
		else{
			$_SESSION['register'] = "Error";
			header('location:index.php');
		}

		
		

	}
}




 ?>
