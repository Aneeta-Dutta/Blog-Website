<?php 
session_start();
require "../admin/db.php";

$id = $_GET["id"];
$status = $_GET["state"];

if ($status == "DEACTIVATE"){
	$sql = "UPDATE `user` SET `status`='ACTIVE' WHERE `id` = '$id'";
}
else{
	$sql = "UPDATE `user` SET `status`='DEACTIVATE' WHERE `id` = '$id'";
}
$result = mysqli_query($connection, $sql);

if($result){

	$_SESSION['state_changed'] ="status changed";
	header("Location:dashboard.php");
}
else{
	$_SESSION['state_changed'] ="Error";
	header("Location:dashboard.php");
}
