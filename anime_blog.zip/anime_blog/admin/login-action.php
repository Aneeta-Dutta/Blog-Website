<?php 
session_start();
require_once "db.php";

// print_r($_POST);
extract($_POST);

if (isset($submit)){

	if ($email !=="" OR $password !=="") {
		$hash_password = md5($password);
		$sql = "SELECT * FROM `admin` WHERE email='$email' AND password='$hash_password'";
		$result = mysqli_query($connection, $sql);

		$row = mysqli_fetch_assoc($result);

		$num_row = mysqli_num_rows($result);

		if ($num_row > 0){
			$_SESSION['id'] = $row['id'];
			$_SESSION['name'] = $row['name'];

			header("location:dashboard.php");

?>
<!-- <script>
	window.location.href ="dashboard.php";
</script> -->

<?php
		}
		else{
			$_SESSION['login_err'] = "No Result Found";
			header("location:index.php");
		}
	}
}

 ?>