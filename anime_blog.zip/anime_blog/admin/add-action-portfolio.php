<?php 
session_start();
require "db.php";

/*echo "<pre>";
print_r($_FILES);*/





extract($_POST);

if (isset($submit)){
	$image = $_FILES['image']['name'];
	$size =  $_FILES['image']['size'];
	
	$maxSize = 1024*1024;

	if ($size > $maxSize) {
		$_SESSION['max_file'] = "File size is larger than 1MB";
			header('location:portfolio.php');
	}
	else{
		$extension = pathinfo($image, PATHINFO_EXTENSION);

	$num = rand(0, 1000000000);

	$rename = "portfolio_img_".date('ymd').$num;

	$filename = $rename.'.'.$extension;

	$upload = 'portfolio_image';

	$actual_path = $upload.'/'.$filename;

	move_uploaded_file($_FILES['image']['tmp_name'], $actual_path);
		

		$sql = "INSERT INTO `portfolio`(`name`, `details`, `image`) VALUES ('$name', '$details','$filename')";

		$result =  mysqli_query($connection, $sql);

		if ($result){
			$_SESSION['add_portfolio'] = "Add Portfolio Successfully";
			header('location:portfolio.php');

			$cap = rand(0,9999);
			
			/*$mail = 'cdibyayan@gmail.com';
			$subject = 'Hello World';
			$message = 'Hello Student';*/
				

			//$mail = mail($mail, $subject, $message);
		/*	if($mail){
				$_SESSION['mail'] = "mail Sent Successfully";
				
			}
			else{
				$_SESSION['mail'] = "Oops Somthing Went Wrong";
				header('location:portfolio.php');
			}*/
		}
		else{
			$_SESSION['add_portfolio'] = "Error";
			header('location:portfolio.php');
		}
	}

	

		


}




 ?>
