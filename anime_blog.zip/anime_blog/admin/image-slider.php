<?php 
include "header.php";

include 'sidebar.php';
?>
<div class="col-md-9">
	<div class="container">
		<?php 
		if(isset($_SESSION['add_img'])){
			echo"<p>".$_SESSION['add_img']."</p>";
			unset($_SESSION['add_img']);
		 
		}
		elseif (isset($_SESSION['edit_image'])) {
			echo"<p>".$_SESSION['edit_image']."</p>";
			unset($_SESSION['edit_Image']);
		}
		elseif (isset($_SESSION['port_delete'])) {
			echo"<p>".$_SESSION['port_delete']."</p>";
			unset($_SESSION['port_delete']);
		}

		?>
		<h3 class="mt-5">All Image Slider Details</h3>
		<a class="btn btn-primary" href="add-image-slider.php">Add Image Slider</a>
			<table class="table mt-2">
				  <thead>
				    <tr>
				      <th>Id</th>
				      <th>Name</th>
				      <th>Images</th>
				      <th>Edit</th>
				      <th>Delete</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php 
				  	$sql ="SELECT * FROM `image_slider`";

					$result = mysqli_query($connection, $sql);

				  	 while ($get = mysqli_fetch_assoc($result)) {?>
				    <tr>
				      <td><?php echo $get['id']; ?></td>
				      <td><?php echo $get['name']; ?></td>
				      <td><img src="images_slider/<?php echo $get['image']; ?>" width="100px" height="100px"></td>
				      <td><a class="btn btn-primary" href="edit-image.php?id=<?php echo $get['id']?>">Edit</a></td>
				      <td><a class="btn btn-danger" href="delete-image.php?id=<?php echo $get['id']?>">Delete</a></td>
				     
				    </tr>
	<?php
}
?>
				  </tbody>
				</table>
	</div>
</div>


<?php 
include "footer.php";

?>