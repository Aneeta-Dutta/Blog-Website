<?php 
session_start();
require "db.php";

extract($_POST);

if (isset($submit)){
	$image = $_FILES['image']['name'];

	$extension = pathinfo($image, PATHINFO_EXTENSION);

	$num = uniqid();

	$rename = "slider_img_".date('ymd').$num;

	$filename = $rename.'.'.$extension;

	$upload = 'images_slider';

	$actual_path = $upload.'/'.$filename;

	move_uploaded_file($_FILES['image']['tmp_name'], $actual_path);
		

		$sql = "INSERT INTO `image_slider`(`name`, `image`) VALUES ('$name','$filename')";

		$result =  mysqli_query($connection, $sql);

		if ($result){
			$_SESSION['add_img'] = "Add Image Slider Successfully";
			header('location:image-slider.php');
		}
		else{
			$_SESSION['add_img'] = "Error";
			header('location:image-slider.php');
		}

		


}




 ?>
