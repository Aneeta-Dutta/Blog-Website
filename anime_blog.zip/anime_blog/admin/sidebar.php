<section>
	<div class="container-fluid">
		<div class="row">
			<div  class="col-md-3">
				<h2 class=" mt-5 pt-2 text-center">Hello <?php echo $_SESSION['name'] ?></h2>
				<ul class="list-group list-group-flush">
				  <li class="list-group-item"><a href="">User Management</a></li>
				  <li class="list-group-item"><a href="portfolio.php">Portfolio</a></li>
				  <li class="list-group-item"><a href="image-slider.php">Image Slider</a></li>
				</ul>
			</div>	