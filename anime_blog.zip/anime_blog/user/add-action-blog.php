<?php 
session_start();
require "../admin/db.php";

//print_r($_POST);

extract($_POST);

if (isset($submit)){
	$sql = "SELECT * FROM `user` WHERE id = '$id'";

	$res = mysqli_query($connection, $sql);

	$row = mysqli_fetch_array($res);

	$author = $row['name'];


	$date =  date("Y-m-d");
		
		
		$image = $_FILES['image']['name'];

		$extension = pathinfo($image, PATHINFO_EXTENSION);

		$num = uniqid();

		$rename = "user_img_".date('ymd').$num;

		$filename = $rename.'.'.$extension;

		$upload = 'blog_images';

		$actual_path = $upload.'/'.$filename;

		move_uploaded_file($_FILES['image']['tmp_name'], $actual_path);
		

		$sql = 'INSERT INTO `blog`(`name`, `content`, `image`, `author`, `author_id`, `created_at`) VALUES ("'.$name.'","'.$content.'","'.$filename.'","'.$author.'","'.$id.'", "'.$date.'")';

		$result =  mysqli_query($connection, $sql);

		if ($result){
			$_SESSION['register'] = "Blog Inserted Successfully";
			header('location:blog.php');
		}
		else{
			$_SESSION['register'] = "Error";
			header('location:blog.php');
		}

		
		

	
}




 ?>
