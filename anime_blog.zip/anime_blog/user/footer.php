
	</div>
	</div>
</section>
<script src="ckeditor/ckeditor.js"></script>
<script>
	CKEDITOR.replace('editor');
</script>
<!-- <a href="logout.php">logout</a> -->
</body>
</html>