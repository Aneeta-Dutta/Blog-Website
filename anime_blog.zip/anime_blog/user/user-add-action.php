<?php 
session_start();
require "../admin/db.php";

//print_r($_FILES);

extract($_POST);

$hash_password = md5($password);
if (isset($submit_reg)){
	$sql = "SELECT * FROM `user` WHERE email = '$email'";

	$res = mysqli_query($connection, $sql);

	$row = mysqli_num_rows($res);

	if ($row > 0) {
		$_SESSION['email_exist'] = "Email already exists";
		header('location:../index.php');
	}
	else{

		$name = $fname.' '.$lname;
		
		$image = $_FILES['image']['name'];

		$extension = pathinfo($image, PATHINFO_EXTENSION);

		$num = uniqid();

		$rename = "user_img_".date('ymd').$num;

		$filename = $rename.'.'.$extension;

		$upload = 'user_image';

		$actual_path = $upload.'/'.$filename;

		move_uploaded_file($_FILES['image']['tmp_name'], $actual_path);
		

		$sql = "INSERT INTO `user`(`name`, `email`, `password`,`mobile`,`image`,`status`) VALUES ('$name', '$email','$hash_password','$phone','$filename','DEACTIVATE')";

		$result =  mysqli_query($connection, $sql);

		if ($result){
			$_SESSION['register'] = "Register Successfully Please Login";
			header('location:../index.php');
		}
		else{
			$_SESSION['register'] = "Error";
			header('location:../index.php');
		}

		
		

	}
}




 ?>
