<?php 
session_start();
if(!isset($_SESSION['id'])){
	$_SESSION['login_first'] = "Please Login First";
	header('Location:index.php');
}

require "../admin/db.php";



?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin - Dashboard</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome-free-5.15.3-web/css/all.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200&display=swap" rel="stylesheet">
</head>
<body>
	<header>
	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
		  <a class="navbar-brand" href="#">
		  	<h3>Demo Blog</h3>
		  </a>

		  <!-- Toggler/collapsibe Button -->
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span class="navbar-toggler-icon"></span>
		  </button>

	  <!-- Navbar links -->
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		    <ul class="navbar-nav ml-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="logout.php">logout</a>
		      </li>
		    
		    </ul>
		  </div>
	</nav>
</header>

