<?php 
include "header.php";

include 'sidebar.php';

 ?>
			<div class="col-md-9">
				<div class="container">

					<?php 
					$id = $_SESSION['id'];

					$q = "SELECT * FROM `user` WHERE `id` = '$id'";
					$r = mysqli_query($connection, $q);
					$row = mysqli_fetch_assoc($r);

					if ($row['status'] == 'ACTIVE') {?>
						
						<h3 class="mt-5">Blog Details</h3>
							<table class="table">
							  <thead>
							    <tr>
							      <th>Id</th>
							      <th>Title</th>
							      <th>Image</th>
							      <th>Edit</th>
							      <th>Delete</th>
							    </tr>
							  </thead>
							  <tbody>
							  	<?php 
							  	$sql ="SELECT * FROM `blog` WHERE `author_id`='$id'";

								$result = mysqli_query($connection, $sql);

							  	 while ($get = mysqli_fetch_assoc($result)) {?>
							    <tr>
							      <td><?php echo $get['id']; ?></td>
							      <td><?php echo $get['name']; ?></td>
							      <td><img src="blog_images/<?php echo $get['image']; ?>" height="100px" width="100px"
							      	></td>
							      <td><a class="btn btn-success" href="">Edit</a></td>
							      <td><a class="btn btn-danger" href="">Delete</a></td>
							     
							    </tr>
							<?php
						}
						?>
							  </tbody>
							</table>

			<?php
				}
				
				else{ ?>

					<h3 class="mt-5">Your Account is Deactivated</h3>


		<?php
				}

		 ?>

		
				</div>

				
			</div>	
	

	<?php include "footer.php"; ?>
