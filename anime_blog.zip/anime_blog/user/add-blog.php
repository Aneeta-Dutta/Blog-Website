<?php 
include "header.php";

include 'sidebar.php';

 ?>
			<div class="col-md-9">
				<div class="container">

					<?php 
					$id = $_SESSION['id'];

					$q = "SELECT * FROM `user` WHERE `id` = '$id'";
					$r = mysqli_query($connection, $q);
					$row = mysqli_fetch_assoc($r);

					if ($row['status'] == 'ACTIVE') {?>
						
						<h3 class="mt-5">Add New Blog</h3>
							
					<div class="w-50 mt-3">
						<form action="add-action-blog.php" method="post" enctype="multipart/form-data">
			        	
						<div class="form-group">
			        		<label>Title</label>
			        		<input type="text" name="name" class="form-control" required="">
			        	</div>
			        	
			        	<div class="form-group">
			        		<label>Content</label>
			        		<textarea id="editor" name="content" class="form-control">
			        			
			        		</textarea>
			        	</div>

			        	<div class="form-group">
			        		<label>Upload Image</label>
			        		<input type="file" name="image" class="form-control" required="">
			        	</div>

			        	<input type="hidden" name="id" value="<?php echo $id ?>">
			        
			        	<button type="submit" name="submit" value="submit" class="btn btn-success">Submit</button>
			        	
			        </form>
					</div>

			<?php
				}
				
				else{ ?>

					<h3 class="mt-5">Your Account is Deactivated</h3>


		<?php
				}

		 ?>

		
				</div>

				
			</div>	
	

	<?php include "footer.php"; ?>
